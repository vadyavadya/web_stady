// Конфигурация FTP соединения
export let configFTP = {
	host: "host",
	user: "user",
	password: "pass",
	parallel: 10
}
// Путь к папке.
// (!) Gulp добавит имя проекта (корневой папки) автоматически
export let pathFTP = `/путь/к/папке/c/проектами/на/сервере`;