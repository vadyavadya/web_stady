// Проверка мобильного браузера
// import { isMobile } from "./functions";

/*
// Пусть переменная "num" будет!
let num;
console.log(typeof num);
console.log(num);

// Пусть переменная "num" содержит число 10
num = 10;
console.log(typeof num);
console.log(num);

// Пусть переменная "num" содержит строку Привет!
num = "Привет!";
console.log(typeof num);
console.log(num);
*/

// Пусть константа "mainPage" ВСЕГДА содержит объект с классом .page
// const mainPage = document.querySelector('.page');

/*
const user = {
	name: "Максим",
	age: "26"
}
user.name = "Лоцы";
console.log(user.name);
*/

// Операторы
// - + * / 
// оператор сложения "+" НЕ преобразовывает тип данных
/*
let num = 100;
let sayHi = "Привет";
let blockHeight = num + sayHi;
console.log(typeof blockHeight);
console.log(blockHeight);
*/
/*
let partOne = "Привет,";
let partTwo = "Вася";
let sayHi = partOne + partTwo;
console.log(sayHi);
*/

// Операторы сравнения > < >= <= == === != !==
/*
let numOne = 10;
let numTwo = "10";
let result = numOne !== numTwo;
console.log(typeof result);
console.log(result);
*/

// Условное ветвление
/*
let numOne = 10;
let numTwo = 30;

if (numOne > numTwo) {
	// Выполняем програму,
	// если условие выполненно (true)
	console.log('numOne больше чем numTwo');
} else if (numTwo === 20) {
	console.log('numTwo равно 20');
} else {
	console.log('Условия НЕ выполненны!');
}
*/

/*
let numOne;
// Возвращают false: undefined, 0, "", NaN
if (numOne) {
	console.log('numOne возвращает true');
} else {
	console.log('numOne возвращает FALSE');
}*/
/*
const mainPage = document.querySelector('.page');
if (mainPage) {
	console.log(mainPage);
}
*/

// Логические операторы || && !
/*
let numOne = 50;
let numTwo = 30;
if (numOne < numTwo && numOne === 50 || numTwo !== 40 && numOne > 35) {
	console.log('Выполняем код...');
}
*/
/*
const blockElement = document.querySelector('.block');
if (!blockElement.classList.contains('active')) {
	blockElement.classList.add('active');
}
*/

//let someVar = "Я строка!";
//let someVar = 'Я строка!';
// Обратные кавычки
//let someVar = `Я строка!`;
/*
let someNum = 21;
let someString = `Мне ${someNum} лет`;
console.log(someString);
*/

/*
// Область видимости
let someNum = 10;
let someString;
if (10 > 5) {
	someString = "Привет!";
}
console.log(someString);
*/

// Функции

// Создание функции
/*
function setConsole(someData) {
	// Выполняемый код
	console.log(someData);
}
// Вызов функции
setConsole("Привет!");
*/

/*
function getSumm(numOne = 5, numTwo = 10) {
	return numOne + numTwo;
}

let someNumber = 580;

if (someNumber === 100) {
	console.log(getSumm(80, 50));
} else {
	console.log(getSumm(10, 10));
}
*/
// ... продолжаем...

















































